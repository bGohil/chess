﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChessBoardGame
{
    public class Rook
    {
        //validation required to check whether it moved to correct direction or not
        public bool CheckIsValidMove(int numberOftep, Directions directions)
        {
            bool IsValidMove = false;
            if (directions != Directions.Backward && directions != Directions.Forward && directions != Directions.Left && directions != Directions.Right)
                IsValidMove = false;

            return IsValidMove;
        }
    }
}
