﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChessBoardGame
{
    class Program
    {
        private static List<ChessBoardDetails> chessBoard = new List<ChessBoardDetails>();
        static void Main(string[] args)
        {
            string playerType = "";
            while (string.IsNullOrEmpty(playerType))
            {
                Console.WriteLine("Who is the 1st player ? Black(1) : White(2)");
                playerType = Console.ReadLine();
                if (playerType != PlayerTypes.BlackPlayer.ToString() && playerType != PlayerTypes.WhitePlayer.ToString())
                {
                    Console.WriteLine("Please insert correct input");
                    playerType = "";
                }
                else
                {
                    CreateChessBoard();

                    ChessPlayer blackPeicePlayer = new ChessPlayer();
                    blackPeicePlayer.PlayerType = PlayerTypes.BlackPlayer;
                    blackPeicePlayer.IsCurrentPlayer = playerType == PlayerTypes.BlackPlayer.ToString() ? true : false;
                    blackPeicePlayer.createInitialBoard();

                    ChessPlayer whitePeicePlayer = new ChessPlayer();
                    whitePeicePlayer.PlayerType = PlayerTypes.BlackPlayer;
                    whitePeicePlayer.IsCurrentPlayer = playerType == PlayerTypes.WhitePlayer.ToString() ? true : false;
                    whitePeicePlayer.createInitialBoard();
                }
            }
        }

        private static void CreateChessBoard()
        {
            for (int i = 1; i <= 8; i++)
            {
                for (int j = 1; j <= 8; j++)
                {
                    ChessBoardDetails chessBoardDetails = new ChessBoardDetails();
                    chessBoardDetails.HorizontalLineNumber = i;
                    chessBoardDetails.VerticalLineNumber = j;
                    if (i == 1 || i == 2 || i == 7 || i == 8)
                    {
                        if (j == 1 || j == 2)
                            chessBoardDetails.IsEmpty = false;
                    }
                    if (i == 1)
                    {

                        if (j == 1 || j == 8)
                        {
                            chessBoardDetails.PieceType = PieceTypes.Rook;
                        }
                        else if (j == 2 || j == 7)
                        {
                            chessBoardDetails.PieceType = PieceTypes.Knight;
                        }
                        else if (j == 3 || j == 6)
                        {
                            chessBoardDetails.PieceType = PieceTypes.Bishop;
                        }
                        else if(j==4)
                            chessBoardDetails.PieceType = PieceTypes.King;
                        else if (j == 5)
                            chessBoardDetails.PieceType = PieceTypes.Queen;
                    }
                    
                }
            }
        }

        public static void PerformAction(ChessPlayer currentPlayer, PieceTypes pieceType, int steps, Directions direction)
        {
           

        }

    }
}
